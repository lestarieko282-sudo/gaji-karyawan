# Gaji PKS Android - versi awal

Aplikasi Android sederhana untuk satu karyawan, dibuat dengan Android WebView dan halaman HTML offline. Data absensi/profil disimpan lokal melalui localStorage pada perangkat yang menjalankan aplikasi.

## Fitur
- Profil satu karyawan (nama, nomor, golongan SKU H/SKU B, jabatan, departemen).
- Gaji pokok, tunjangan, potongan tetap.
- Absensi harian dengan jam masuk/pulang, istirahat, status, catatan.
- Jam kerja lintas tengah malam.
- HK standar 7 jam dan hari pendek 5 jam.
- Upah lembur hari biasa: jam pertama 1,5x upah per jam, berikutnya 2x.
- Lembur hari libur: estimasi sederhana untuk pola 6 hari kerja (7 jam pertama 2x, jam ke-8 3x, berikutnya 4x).
- Rekap bulanan, ekspor CSV, cetak/simpan PDF melalui dialog cetak Android.

## Build menjadi APK
1. Instal Android Studio versi stabil dan Android SDK Platform 35.
2. Ekstrak folder `PKSGajiAndroid`.
3. Android Studio > Open > pilih folder `PKSGajiAndroid`.
4. Tunggu Gradle Sync. Jika diminta, izinkan Android Studio mengunduh Android Gradle Plugin/Kotlin plugin.
5. Hubungkan HP Android dengan USB debugging aktif, lalu tekan Run; atau pilih Build > Build APK(s).
6. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Asumsi awal yang harus diperiksa
- Gaji pokok awal Rp3.686.138, dapat diubah di menu Karyawan.
- Tarif HK dikunci otomatis = gaji pokok / 25; tidak dapat ditimpa manual.
- Upah lembur per jam = gaji pokok / 173.
- Upah HK bulanan = jumlah HK hadir × (gaji pokok / 25).
- Hari OFF/libur tanpa kehadiran, izin, sakit, dan alpha tidak menambah HK. Hari berstatus Hadir dengan jam kerja > 0 dihitung 1 HK, termasuk jika masuk pada hari libur; jamnya masuk perhitungan lembur hari libur.
- Jam normal 7 jam, hari pendek 5 jam.
- Untuk hari libur, rumus lembur yang diterapkan merupakan estimasi umum untuk pola 6 hari kerja dan perlu diverifikasi terhadap aturan resmi/perusahaan, khususnya jika jenis hari libur atau jumlah jam kerja berbeda.
- Versi ini tidak mengelola BPJS/PPh21, pinjaman, potongan dinamis, beberapa karyawan, sinkronisasi cloud, atau backup otomatis.

## Privasi dan penyimpanan
Data disimpan lokal pada aplikasi/perangkat dan tidak dikirim ke server. Menghapus data aplikasi dapat menghapus data yang tersimpan. Ekspor CSV secara berkala untuk cadangan.

## Build APK tanpa komputer (GitHub Actions)
Proyek ini menyertakan workflow `.github/workflows/build-apk.yml`. Unggah seluruh isi folder proyek ke repository GitHub, lalu buka tab Actions dan jalankan workflow **Build APK Gaji PKS**. Jika berhasil, buka hasil workflow dan unduh artifact `Gaji-PKS-debug-APK` (ZIP berisi APK). Ekstrak ZIP artifact di HP, lalu pasang APK. Repository harus mengizinkan GitHub Actions. Artifact build tersedia sementara sesuai masa retensi workflow.
